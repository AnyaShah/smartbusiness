<div class="site-block-wrap">
    <div class="owl-carousel with-dots">
      <div class="site-blocks-cover overlay overlay-2" style="background-image: url(images/hero_1.jpg);" data-aos="fade" id="home-section">


        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-md-6 mt-lg-5 text-center">
              <h1 class="text-shadow">Buy &amp; Sell Products Here</h1>
              <p class="mb-5 text-shadow">   </p>
              
              
            </div>
          </div>
        </div>
     </div>
  
        
     
  
      <div class="site-blocks-cover overlay overlay-2" style="background-image: url(images/hero_2.jpg);" data-aos="fade" id="home-section">
  
  
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-md-6 mt-lg-5 text-center">
              <h1 class="text-shadow">Find Your Perfect Product For Your Shop</h1>
              <p class="mb-5 text-shadow">  </p>
              
              
            </div>
          </div>
        </div>
  
        
      </div>  
</div>
</div>