<?php
ob_start();
session_start();
    include('include/header.php');
    if($_SESSION['userRole']==1)
    {
        include('include/sidebar.php');
    }
    if($_SESSION['userRole']==2)
    {
        include('include/sidebar1.php');
    }
    include('include/connection.php');
    $users = mysqli_query($con, "select * from userlogin INNER JOIN user_role on userlogin.u_role=user_role.u_roleid ");
?>
        <!-- Start: Content-Wrapper -->
        <section id="content_wrapper">

            <!-- Begin: Content -->
            <section id="content" class="animated fadeIn">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-users"></i><span class="panel-title">User</span>
                         

                        </div>
                        <div class="panel-body">
                            <table class="table table-striped table-hover table-responsive" id="datatable2" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>User Name</th>
                                        <th>User Email</th>
                                        <th>User Password</th>
                                        <th>User Contact</th>
                                        <th>User City</th>
                                        <th>User Address</th>
                                        <th>User Type</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    while($user = mysqli_fetch_array($users))
                                    {
                                ?>
                                    <tr>
                                        <td><?php echo $user['u_id']?></td>
                                        <td><?php echo $user['u_name']?></td>
                                        <td><?php echo $user['u_email']?></td>
                                        <td><?php echo $user['u_pass']?></td>
                                        <td><?php echo $user['u_contact']?></td>
                                        <td><?php echo $user['u_city']?></td>
                                        <td><?php echo $user['u_address']?></td>
                                        <td><?php echo $user['u_role']?></td>
                                        <td><?php echo $user['Status']==1 ? 'Active' : 'InActive'?></td>
                                        
                                        
                                    </tr>
                                <?php
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
    
            </section>
            <!-- End: Content -->

        </section>
        <!-- End: Content-Wrapper -->
    </div>
    <!-- End: Main -->
<?php
include 'adminfooter.php';
?>
<?php
ob_end_flush();
?>