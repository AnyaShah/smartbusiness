<?php
ob_start();
 session_start();
    include('include/header.php');
    if($_SESSION['userRole']==1)
    {
        include('include/sidebar.php');
    }
    if($_SESSION['userRole']==2)
    {
        include('include/sidebar1.php');
    }
    $con = mysqli_connect("localhost","root","","smartbusiness");
    $categories = mysqli_query($con,"select * from categories");
    
    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
        $query = mysqli_query($con,"select * from products where p_id = $id");
          while($fetch=mysqli_fetch_array($query)){

        }
    }
?>
        <!-- Start: Content-Wrapper -->
        <section id="content_wrapper">

            <!-- Begin: Content -->
            <section id="content" class="animated fadeIn">
                <div class="row">
                    <div class="col-md-9 center-block">


                        <!-- Form Wizard -->
                        <div class="admin-form theme-primary">

                            <div class="panel">

                                <form method="post" action="#" id="admin-form" enctype="multipart/form-data">
                                    <div class="panel-body">

                                        <div class="section-divider mb40 mt20"><span> Add Product </span>
                                        </div><!-- .section-divider -->

                                        <div class="section row">
                                            <div class="col-md-6">
                                                <select name="category" class="form-control">
                                                    <option value="" disabled selected>Select Category</option>
                                                    <?php
                                                        while($category = mysqli_fetch_array($categories))
                                                        {
                                                    ?>
                                                    <option value="<?php echo $category['cat_id']?>"> <?php echo $category['cat_name']?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div><!-- end section -->
                                           
                                        </div><!-- end .section row section -->
                                        <div class="section row">
                                    
                                                
                                            <div class="col-md-6">
                                                <label for="name" class="field prepend-icon">
                                                    <input type="text" name="name" id="name" class="gui-input"
                                                        placeholder="Enter Name..." value='<?php echo isset($fetch['name']) ? $fetch['name'] : null?>'>
                                                    <label for="name" class="field-icon"><i
                                                            class="fa fa-user"></i></label>
                                                </label>
                                            </div><!-- end section -->
                                        </div><!-- end .section row section -->
                                        <div class="section row">
                                            <div class="col-md-4">
                                                <label for="price" class="field prepend-icon">
                                                    <input type="text" name="price" id="price" class="gui-input"
                                                        placeholder="Enter Price..." value='<?php echo isset($fetch['price']) ? $fetch['price'] : null?>'>
                                                    <label for="price" class="field-icon"><i
                                                            class="fa fa-user"></i></label>
                                                </label>
                                            </div><!-- end section -->
                                            <div class="col-md-4">
                                                <label for="stock" class="field prepend-icon">
                                                    <input type="text" name="stock" id="stock" class="gui-input"
                                                        placeholder="Enter Quanity..." value='<?php echo isset($fetch['stock']) ? $fetch['stock'] : null?>'>
                                                    <label for="stock" class="field-icon"><i
                                                            class="fa fa-user"></i></label>
                                                </label>
                                            </div><!-- end section -->

                                            <div class="col-md-4">
                                                <label for="ExpireDate" class="field prepend-icon">
                                                    <input type="date" name="ExpireDate" id="ExpireDate" class="gui-input"
                                                        placeholder="Enter ExpireDate" value='<?php echo isset($fetch['ExpireDate']) ? $fetch['ExpireDate'] : null?>'>
                                                    <label for="ExpireDate" class="field-icon"><i
                                                            class="fa fa-user"></i></label>
                                                </label>
                                            </div><!-- end section -->
                                            
                                        </div><!-- end .section row section -->
                                        <!-- end section -->
                                        <div class="section row">
                                            <div class="col-md-12">
                                                <textarea style='width:100%;' name="long_description" id="" cols="100" rows="7" placeholder="Description">
                                                <?php echo isset($fetch['long_description']) ? $fetch['long_description'] : null?>
                                                </textarea>
                                            </div>
                                        </div><!-- end section -->
                                      
                                        <div class="section">
                                            <label for="file1" class="field file">
                                                <span class="button btn-primary"> Choose File </span>
                                                <input type="file" class="gui-file" name="image" id="file1"
                                                    onChange="document.getElementById('uploader1').value = this.value;">
                                                <input type="text" class="gui-input" id="uploader1"
                                                    placeholder="no file selected" readonly>
                                            </label>
                                        </div><!-- end  section -->
                                        <div class="section row">
                                        <div class="col-md-12">
                                            
                                        </div>
                                    </div><!-- end section -->
                                        
                                    </div><!-- end .form-body section -->
                                    <div class="panel-footer text-right">
                                        <a href="products.php">
                                            <button type="button" class="button btn-primary"> Go Back </button>
                                        </a>
                                        <button type="submit" name="submit" class="button btn-primary"> Save </button>
                                    </div><!-- end .form-footer section -->
                                </form>
                                <?php
                                    if(isset($_POST['submit']))
                                    {
                                        
                                        $category           = $_POST['category'];
                                        $image              = $_FILES['image']['name'];
                                        $tmp_dir            = $_FILES['image']['tmp_name'];
                                        $dir                = 'uploads/'.$image;
                                        $name               = $_POST['name'];
                                        $price              = $_POST['price'];
                                        $stock              = $_POST['stock'];
                                        $long_description   = $_POST['long_description'];
                                        $expire             =$_POST['ExpireDate'];


                                        
                                       if(!empty($image))
                                       {
                                           move_uploaded_file($tmp_dir,$dir);
                                       }
                                       else
                                       {
                                           $image = $fetch['image'];
                                       }
                                        if(isset($_GET['id']))
                                        {

                                            
                                            $update = "UPDATE productdetail SET  p_name ='$name' p_img='$dir', p_price='$price', p_qty='$stock', p_disc='$long_description', p_exp='$expire' WHERE p_id = $id";
                                            $sql_query = mysqli_query($con,$update);
                                        }
                                        else
                                        {
                                            $insert = "INSERT INTO productdetail( cat_id, p_name, p_img, p_price, p_qty, p_disc, p_exp) VALUES ('$category','$name','$dir','$price','$stock','$long_description','$expire')";
                                            $sql_query = mysqli_query($con,$insert);
                                        }
                                        if($sql_query)
                                        {
                                            header('location:products.php');
                                        }
                                        else
                                        {
                                            die(mysqli_error($con));
                                        }
                                    }
                                ?>
                            </div>

                        </div>
                        <!-- end: .admin-form -->

                    </div>

                </div>

            </section>
            <!-- End: Content -->

        </section>
        <!-- End: Content-Wrapper -->
    </div>
    <!-- End: Main -->

    <!-- BEGIN: PAGE SCRIPTS -->

    <!-- jQuery -->
    <script type="text/javascript" src="vendor/jquery/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="vendor/jquery/jquery_ui/jquery-ui.min.js"></script>

    <!-- Bootstrap -->
    <script type="text/javascript" src="assets/js/bootstrap/bootstrap.min.js"></script>

    <!-- Sparklines CDN -->
    <script type="text/javascript"
        src="http://cdnjs.cloudflare.com/ajax/libs/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script>

    <!-- Chart Plugins -->
    <script type="text/javascript" src="vendor/plugins/highcharts/highcharts.js"></script>
    <script type="text/javascript" src="vendor/plugins/circles/circles.js"></script>
    <script type="text/javascript" src="vendor/plugins/raphael/raphael.js"></script>

    <!-- Holder js  -->
    <script type="text/javascript" src="assets/js/bootstrap/holder.min.js"></script>

    <!-- Theme Javascript -->
    <script type="text/javascript" src="assets/js/utility/utility.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/demo.js"></script>

    <!-- Admin Panels  -->
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/json2.js"></script>
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/jquery.ui.touch-punch.min.js">
    </script>
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/adminpanels.js"></script>

    <!-- Page Javascript -->
    <script type="text/javascript" src="assets/js/pages/widgets.js"></script>
    
    <!-- END: PAGE SCRIPTS -->

</body>

</html>
<?php
ob_end_flush();
?> 
