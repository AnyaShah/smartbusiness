
        <!-- Start: Sidebar -->
        <aside id="sidebar_left" class="nano nano-primary">
            <div class="nano-content">
                <!-- sidebar menu -->
                <ul class="nav sidebar-menu">
                    <li class="sidebar-label pt20">Menu</li>
                 
                   
                    <li>
                        <a href="categories.php">
                            <span class="glyphicons glyphicons-book_open"></span>
                            <span class="sidebar-title">Categories</span>
                        </a>
                    </li>
                    <li>
                        <a href="products.php">
                            <span class="fa fa-calendar"></span>
                            <span class="sidebar-title">Products</span>
                        </a>
                    </li>
                    <li>
                        <a href="retilerorders.php">
                            <span class="fa fa-calendar"></span>
                            <span class="sidebar-title">orders</span>
                        </a>
                    </li>
                  
                   
                </ul>
                <div class="sidebar-toggle-mini">
                    <a href="#">
                        <span class="fa fa-sign-out"></span>
                    </a>
                </div>
            </div>
        </aside>
