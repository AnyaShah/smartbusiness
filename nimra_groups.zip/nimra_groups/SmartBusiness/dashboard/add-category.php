<?php
    ob_start();
    session_start();
    include('include/header.php');
    if($_SESSION['userRole']==1)
    {
        include('include/sidebar.php');
    }
    if($_SESSION['userRole']==2)
    {
        include('include/sidebar1.php');
    }
    include('include/connection.php');
    $categories = mysqli_query($con,'select * from categories');
    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
        $query = mysqli_query($con,"select * from categories where id = '$id'");
        $fetch = mysqli_fetch_array($query);
    }
?>
    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Begin: Content -->
        <section id="content" class="animated fadeIn">
            <div class="row">
                <div class="col-md-9 center-block">


                    <!-- Form Wizard -->
                    <div class="admin-form theme-primary">

                        <div class="panel">

                            <form method="post" action="" id="admin-form"  enctype='multipart/form-data'>
                                <div class="panel-body">

                                    <div class="section-divider mb40 mt20"><span> Add Catogeries </span>
                                    </div><!-- .section-divider -->
                               
                                    <div class="section row">
                                        <div class="col-md-12">
                                            <label for="name" class="field prepend-icon">
                                                <input type="text" name="name" id="name" class="gui-input"
                                                    placeholder="Name..."  value='<?php echo isset($fetch['name']) ? $fetch['name'] : null?>'>
                                                <label for="name" class="field-icon"><i
                                                        class="fa fa-user"></i></label>
                                            </label>
                                        </div><!-- end section -->
                                    </div>
                                    <!-- end  section -->
                                    <div class="section row">
                                    
                                </div><!-- end section -->
                                <div class="panel-footer text-right">
                                    <a href="categories.php">
                                        <button type="button" class="button btn-primary"> Go Back </button>
                                    </a>
                                    <button type="submit" name="submit" class="button btn-primary"> Save </button>
                                </div><!-- end .form-footer section -->
                            </form>
                            <?php
                                if(isset($_POST['submit']))
                                {
                                    $name = $_POST['name'];

                                 
                                    if(isset($_GET['id']))
                                    {
                                        // update
                                        $update = "UPDATE categories SET cat_name = '$name' where cat_id = '$id'";
                                        $sql = mysqli_query($con,$update);
                                    }
                                    else
                                    {
                                        $insert = "INSERT INTO categories(cat_name) VALUES ('$name')";
                                        $sql = mysqli_query($con,$insert);
                                    }
                                    
                                    if($sql)
                                    {
                                        header('location:categories.php');
                                    }
                                }
                            ?>
                        </div>

                    </div>
                    <!-- end: .admin-form -->

                </div>

            </div>

        </section>
        <!-- End: Content -->
    </section>
    <!-- End: Content-Wrapper -->
    </div>
    <!-- End: Main -->

    <!-- BEGIN: PAGE SCRIPTS -->

    <!-- jQuery -->
    <script type="text/javascript" src="vendor/jquery/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="vendor/jquery/jquery_ui/jquery-ui.min.js"></script>

    <!-- Bootstrap -->
    <script type="text/javascript" src="assets/js/bootstrap/bootstrap.min.js"></script>

    <!-- Sparklines CDN -->
    <script type="text/javascript"
        src="http://cdnjs.cloudflare.com/ajax/libs/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script>

    <!-- Chart Plugins -->
    <script type="text/javascript" src="vendor/plugins/highcharts/highcharts.js"></script>
    <script type="text/javascript" src="vendor/plugins/circles/circles.js"></script>
    <script type="text/javascript" src="vendor/plugins/raphael/raphael.js"></script>

    <!-- Holder js  -->
    <script type="text/javascript" src="assets/js/bootstrap/holder.min.js"></script>

    <!-- Theme Javascript -->
    <script type="text/javascript" src="assets/js/utility/utility.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/demo.js"></script>

    <!-- Admin Panels  -->
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/json2.js"></script>
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/jquery.ui.touch-punch.min.js">
    </script>
    <script type="text/javascript" src="assets/admin-tools/admin-plugins/admin-panels/adminpanels.js"></script>

    <!-- Page Javascript -->
    <script type="text/javascript" src="assets/js/pages/widgets.js"></script>
   
    <?php
   ob_end_flush();
   ?>